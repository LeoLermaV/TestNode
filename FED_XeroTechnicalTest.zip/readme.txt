XeroTechnicalTest consists of a Node.js console application.

Notes:
- This project requires Node v6 or higher.
- Feel free to use ES6 syntax

Instructions for test are listed in the comments at the top of index.js.

Good luck!